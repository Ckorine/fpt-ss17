package fpt.interfaces;

/**
 * Created by corin on 16.05.2017.
 */
public interface ButtonAction {
    void play();
    void stop();
}
