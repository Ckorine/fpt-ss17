## FPT SS17 

This Repo provides the initial project for FPT.

# Step by Step guide for setting up your own private Repo

1. Create an account on a Git Service provider of your choice
2. Create a **private** Repo and add your teammates to that repo, so that they are able to push changes.
3. Put the provided project in your Repo and try importing it, as seen on the slides in Moodle.
4. Solve the excercise and use meaningful commit logs
5.
